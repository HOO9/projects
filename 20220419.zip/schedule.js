var partyArr = [];
var endpointArr = [];

//function call_server(server_url,paramInfo) {
//    return $.ajax({
//    	async: true,
//    	type: "POST", 
//    	url: server_url, 
//    	data : paramInfo,
//    	dataType: "json", 
//    	headers: {"AJAX": "true"}, 
//    	success: function (result) {
//    		return result;
//		},
//		beforeSend:function(){
//			$('.Progress_Loading').show();
//		},
//		complete:function(){
//			$('.Progress_Loading').hide();
//		}, 
//		error: function (xhr, ajaxOptions, thrownError) {
//			if(xhr.status == 400){
//				alert("세션이 만료되었습니다. 다시 로그인하시기 바랍니다.");
//				location.href="/index.do";
//			}else{
//				alert(thrownError);
//			}
//		}
//	});
//}

String.prototype.string = function(len){var s = '', i = 0; while (i++ < len) { s += this; } return s;};
String.prototype.zf = function(len){return "0".string(len - this.length) + this;};
Number.prototype.zf = function(len){return this.toString().zf(len);};

//update
function fn_respop (value){
 	var url = ctx + "/pages/detailPageSearch.do";
 	var paramInfo = {};
 	paramInfo.MEETINGTYPE = '';
 	paramInfo.SCHEDULE_ID = value;
 	
 	ajax(url,paramInfo).done(function(data){
 		$.each(data.SCHEDULE, function(idx, item){
 			
 			var s_date = item.START_DATE;
			var s_time = item.START_TIME;
			var e_date = item.END_DATE;
			var e_time = item.END_TIME;
 			
			$("#conf_title").val( item.TITLE );
			$("#startDate").val(s_date.substr(0,4) + '.' + s_date.substr(4,2) + '.' +s_date.substr(6,2));
			$("#startDate").datepicker({ dateFormat: "yy.mm.dd" });
			$("#endDate").val(e_date.substr(0,4) + '.' + e_date.substr(4,2) + '.' + e_date.substr(6,2));
			$("#endDate").datepicker({ dateFormat: "yy.mm.dd" });
			$("#hourbox_start").val(s_time.substr(0,2));
			$("#minbox_start").val(s_time.substr(2,2));
			$("#hourbox_end").val(e_time.substr(0,2));
			$("#minbox_end").val(e_time.substr(2,2));
			$("#conf_pass").val(item.PASSCODE);
			$("#conf_contents").val(item.CONTENTS);
	     	 
	     	selectDur =  item.DURATION;
	     	$("#duration").empty();
	     	$("#duration").append("<option value='" + selectDur + "' selected>" + selectDur + minText + "</option>");
	     	 
	     	if(item.RECORDING_YN == "Y"){
	     		$("#ra_in").prop( "checked", true );
	     		$("#ra_out").prop( "checked", false );
	     	}else{
	     		$("#ra_in").prop( "checked", false );
	     		$("#ra_out").prop( "checked", true );
	     	}
	     	
	     	$('#resPopDialog').attr('schedule_id',item.SCHEDULE_ID);
	    	$('#resPopDialog').attr('cospace_id',item.COSPACE_ID);
	     	$('#resPopDialog').attr('schedule_type',"U");
	     	$(".reserv_check").css("height","400px");
	     	$("#resPopDialog").css({display:"block"});
	     	
	     	partyArr = [];
	     	if(item.PARTICIPANTS != null) {
	     		$.each(item.PARTICIPANTS, function(idx, item){
	         		var party = {};
	         		party.EMAIL = item.EMAIL;
	         		party.SCHEDULE_ID = item.SCHEDULE_ID;
	         		party.MEMBER_NM = item.MEMBER_NM;
	         		party.MEMBER_ID = item.MEMBER_ID;
	         		partyArr[idx] = party;
	         	});
	     		$('#resPopDialog').attr('partyList',JSON.stringify(partyArr)); 
	     	 }
	     	 
	     	endpointArr = [];
	     	if(item.ENDPOINTS != null) {
	    		 $.each(item.ENDPOINTS, function(idx, item){
	    			 var endpoint = {};
	    			endpoint.RES_KEY = item.RES_KEY;
	    			endpoint.SCHEDULE_ID = item.SCHEDULE_ID;
	    			endpoint.ENDPOINT_NM = item.RES_NM;
	    			endpoint.ENDPOINT_TYPE = item.ENDPOINT_TYPE;
	    			endpointArr[idx] = endpoint;
	    		 });
	    		$('#resPopDialog').attr('res_endpoints_arr',JSON.stringify(endpointArr)); 
	    	}
	     	
	     	$("#resPopDialog").dialog({
	     		dialogClass : 'reservePopDialog',
//	     		height: 525,
	            width : 608
	     	});
	     	$("#resPopDialog").dialog("open");
	     	$('.reservePopDialog .ui-widget-header').css({'background': 'transparent url(' + ctx + '/resources/public/images/icon_reservation.png) no-repeat top left', 'margin': '10px 20px 10px 20px'});
	    	$('.reservePopDialog .ui-dialog-title').css({'margin': '-5px 13px','border-bottom': 'none', 'padding-bottom': '0', 'width': '433px', 'color': '#000'});
	    	$('.reservePopDialog .ui-icon-closethick').css('margin', '0 !important');
 		});	
 	});
 };


function fn_respop_detail(value){
	var url = ctx + "/pages/detailPageSearch.do";
 	var paramInfo = {};
 	paramInfo.MEETINGTYPE = '';
 	paramInfo.SCHEDULE_ID = value;
 	
 	ajax(url,paramInfo).done(function(data){
 		$.each(data.SCHEDULE, function(idx, item){
	 		var scheduleType = item.SCHEDULE_TYPE;
	 		var s_date = item.START_DATE;
	 		var s_time = item.START_TIME;
	 		var startDate = new Date(item.START_DATE_TIME.replace("-","/"));
			var nowDate = new Date();
	 		var meetingKey;
	 		var hostKey = item.HOST_KEY == null ? "":item.HOST_KEY;
	 		
	 		if(item.MEETING_KEY != null)
	 			meetingKey = item.MEETING_KEY.slice(0,4) + " " + item.MEETING_KEY.slice(4,8) + " " + item.MEETING_KEY.slice(8);
	 		 
	        $("#detail_conf_title_confirm").text( item.TITLE );
	        $("#detail_conf_date_confirm").text(item.START_DATE_TIME.substr(0,16) + " ~ " + item.END_DATE_TIME.substr(0,16) + " ("+ item.DURATION + minText +")");
	     	$("#detail_conf_host_confirm").text(item.INPUT_NM);
	     	$("#detail_conf_contents_confirm").val(item.CONTENTS);
	     	$('#detail_conf_meetingKey_confirm').text(meetingKey);
	     	 
	     	$("#resDetailPopupDialog").css({display:"block"});
	     	$('#resDetailPopupDialog').attr('schedule_id',item.SCHEDULE_ID);
	     	$('#resDetailPopupDialog').attr('cospace_id',item.COSPACE_ID);
	     	$('#resDetailPopupDialog').attr('startdate',item.START_DATE+item.START_TIME +'00');
	     	$('#resDetailPopupDialog').attr('duration',item.DURATION);
	     	
	     	$(".reserv_check").css("height","440px");
	     	 
	     	
	     	partyArr = [];
	     	if(item.PARTICIPANTS != null) {
	        	$.each(item.PARTICIPANTS, function(idx, item){
	        		var party = {};
	        		party.EMAIL = item.EMAIL;
	        		party.SCHEDULE_ID = item.SCHEDULE_ID;
	        		party.MEMBER_NM = item.MEMBER_NM;
	        		party.MEMBER_ID = item.MEMBER_ID;
	        		partyArr[idx] = party;
	        	});
	        	$('#resDetailPopupDialog').attr('detailpartyList',JSON.stringify(partyArr)); 
	     	}
	     	
	     	endpointArr = [];
	     	if(item.ENDPOINTS != null) {
		   		$.each(item.ENDPOINTS, function(idx, item){
		   			var endpoint = {};
		   			endpoint.RES_KEY = item.RES_KEY;
		   			endpoint.SCHEDULE_ID = item.SCHEDULE_ID;
		   			endpoint.ENDPOINT_NM = item.RES_NM;
		   			endpoint.ENDPOINT_TYPE = item.ENDPOINT_TYPE;
		   			endpointArr[idx] = endpoint;
		   		});
	   		 $('#resDetailPopupDialog').attr('detailendpointList',JSON.stringify(endpointArr)); 
	     	 }
	     	
	     	$('#detail_update').hide();
			$('#detail_delete').hide();
			
	    	if(startDate > nowDate && userId == item.INPUT_ID && scheduleType != "CD0203") {
				$('#detail_update').show();
	    		$('#detail_delete').show();
			}
	    	
	    	//내가 예약한 스케줄인 경우 host키 표시
	    	if(userId == item.INPUT_ID) {
	    		$('#detail_conf_hostKey_confirm').text(hostKey);
	    		$('#detail_conf_hostKey_confirm').show();
	    		$('#detail_conf_hostKey').show();
	    	}else{
	    		$('#detail_conf_hostKey_confirm').hide();
	    		$('#detail_conf_hostKey').hide();
	    	}
	    	
//	    	$("#resDetailPopupDialog").dialog().parents(".ui-dialog").find(".ui-dialog-titlebar").remove();
//	    	if(userId == "reservation"){
//				$("#resDetailPopupDialog").dialog({
//					height: 515,
//					width: 635
//				});
//			}else{
//				$("#resDetailPopupDialog").dialog({
//					height: 495,
//		            width : 608
//				});
//			}
//	     	$("#resDetailPopupDialog").dialog("open");
	     	
	     	$("#resDetailPopupDialog").dialog({
				dialogClass : 'reservePopDialog',
				width: 640,
				height: 540
			});
			$("#resDetailPopupDialog").css({padding:"7px 14px"});
			$("#resDetailPopupDialog").dialog("open");
			$('.reservePopDialog .ui-widget-header').css({'background': 'none', 'margin': '10px 20px 0px 20px', 'border': '0'});
			$('.reservePopDialog .ui-dialog-title').css({'margin': '0px -16px','border-bottom': '2px solid #a50034', 'padding-bottom': '6px', 'width': '616px', 'color': '#000'});
			$('.reservePopDialog .ui-icon-closethick').css('margin', '-5');
 	    });	
 	});
};
 
function fn_respop_favorite(value){
	var url = ctx + "/pages/detailPageSearch.do";
 	var paramInfo = {};
 	paramInfo.MEETINGTYPE = '';
 	paramInfo.SCHEDULE_ID = value;
	 	
 	ajax(url,paramInfo).done(function(data){
 		$.each(data.SCHEDULE, function(idx, item){
 			
 			var s_date = item.START_DATE;
	 		var s_time = item.START_TIME;
	 		var e_date = item.END_DATE;
	 		var e_time = item.END_TIME;
		 		
			$("#conf_title").val( item.TITLE );
			$("#startDate").val(s_date.substr(0,4) + '.' + s_date.substr(4,2) + '.' +s_date.substr(6,2));
			$("#startDate").datepicker({ dateFormat: "yy.mm.dd" });
			$("#conf_contents").val(item.CONTENTS);
			$("#hourbox_start").val(s_time.substr(0,2));
			$("#minbox_start").val(s_time.substr(2,2));
			$("#hourbox_end").val(e_time.substr(0,2));
			$("#minbox_end").val(e_time.substr(2,2));
			$("#conf_pass").val(item.PASSCODE);
			$("#conf_userCnt").val(item.USER_CNT);
			     	 
			if(item.RECORDING_YN == "Y"){
		     	$("#ra_in").prop( "checked", true );
		     	$("#ra_out").prop( "checked", false );
		     	$("#label_pass_input").show();
		        $('#label_pass_confirm').val("F");
			}else{
				$("#ra_in").prop( "checked", false );
				$("#ra_out").prop( "checked", true );
				$("#label_pass_input").hide();
				$("#label_pass_confirm").hide();
				$('#label_pass_confirm').val("T");
				$("#RECORD_PW").val("");
			}
		     	 
			$('#resPopDialog').attr('schedule_id',"");
			$('#resPopDialog').attr('cospace_id',item.COSPACE_ID);
			$('#resPopDialog').attr('schedule_type',"I");
			// 참석자 담아주기위해 만든 구분값
			$("#resPopDialog").attr("favorite_type","Y");
		     	 
			$("#resPopDialog").css({display:"block"});
			
			
			partyArr = [];
	     	if(item.PARTICIPANTS != null) {
	         	$.each(item.PARTICIPANTS, function(idx, item){
	         		var party = {};
	         		party.EMAIL = item.EMAIL;
	         		party.SCHEDULE_ID = item.SCHEDULE_ID;
	         		party.MEMBER_NM = item.MEMBER_NM;
	         		party.MEMBER_ID = item.MEMBER_ID;
	         		partyArr[idx] = party;
	         	});
	         	$('#resPopDialog').attr('partyList',JSON.stringify(partyArr)); 
	     	}
	     	 
		    endpointArr = [];
	     	if(item.ENDPOINTS != null) {
	    		$.each(item.ENDPOINTS, function(idx, item){
	    			var endpoint = {};
	    			endpoint.RES_KEY = item.RES_KEY;
	    			endpoint.SCHEDULE_ID = item.SCHEDULE_ID;
	    			endpoint.ENDPOINT_NM = item.RES_NM;
	    			endpoint.ENDPOINT_TYPE = item.ENDPOINT_TYPE;
	    			endpointArr[idx] = endpoint;
	    		});
	    		 
	    		$('#resPopDialog').attr('res_endpoints_arr',JSON.stringify(endpointArr)); 
	     	}
	     	
	     	if(item.ENDPOINTS[0].RES_KEY == "resource") {
	     		$('#resPopDialog').attr('meeting_type',"CD0202");
	     	}else{
	     		$('#resPopDialog').attr('meeting_type',"CD0201");
	     	}
	     	
	     	
	     	$("#resPopDialog").dialog({
				dialogClass : 'reservePopDialog',
//				height: 525,
				width: 608
			});
	     	
	     	$("#resPopDialog").dialog("open");
	     	$('.reservePopDialog .ui-widget-header').css({'background': 'transparent url(' + ctx + '/resources/public/images/icon_reservation.png) no-repeat top left', 'margin': '10px 20px 10px 20px'});
	    	$('.reservePopDialog .ui-dialog-title').css({'margin': '-5px 13px','border-bottom': 'none', 'padding-bottom': '0', 'width': '433px', 'color': '#000'});
	    	$('.reservePopDialog .ui-icon-closethick').css('margin', '0 !important');
	 	});	
 	});
 };
		
$('#bootstrapModalFullCalendar').contextmenu({
    delegate: ".hasmenu",
    autoFocus: true,
    preventContextMenuForPopup: true,
    preventSelect: true,
    taphold: true,
       menu: [
            {title: "Cut <kbd>Ctrl+X</kbd>", cmd: "cut", uiIcon: "ui-icon-scissors"},
            {title: "Copy <kbd>Ctrl+C</kbd>", cmd: "copy", uiIcon: "ui-icon-copy"},
            {title: "Paste <kbd>Ctrl+V</kbd>", cmd: "paste", uiIcon: "ui-icon-clipboard", disabled: true },
            {title: "----"},
            {title: "Edit <kbd>[F2]</kbd>", cmd: "edit", uiIcon: "ui-icon-pencil"},
            {title: "More", children: [
              {title: "Use an 'action' callback", action: function(event, ui) {
                alert("action callback sub1");
                } },
              {title: "Tooltip (static)", cmd: "sub2", tooltip: "Static tooltip"},
              {title: "Tooltip (dynamic)", tooltip: function(event, ui){ return "" + Date(); }},
              {title: "Custom icon", cmd: "browser", uiIcon: "ui-icon custom-icon-firefox"},
              {title: "Disabled (dynamic)", disabled: function(event, ui){
                return false;
                }}
              ]}
            ],
    select: function(event, ui) {
	    var $target = ui.target;
	    switch(ui.cmd){
	        case "copy":
	        	CLIPBOARD = $target.text();
	        	break;
	        case "paste":
	        	CLIPBOARD = "";
	        	break;
	    }
	    alert("select " + ui.cmd + " on " + $target.text());
	    // Optionally return false, to prevent closing the menu now
    }, 
    beforeOpen: function(event, ui) {
	    var $menu = ui.menu,
	    $target = ui.target,
	    extraData = ui.extraData; // passed when menu was opened by call to open()
    }
});

	
var selectedDate = '';	
$('#resPopDialog').dialog({
    autoOpen: false,
    autoResize : true,
    resizable : false,
    closeOnEscape: true,
    modal:true,
    show: {
        effect: "show",
        duration: 1000
    },
    hide: {
        effect: "fadeOut",
        duration: 1000
    },
    hideCloseButton: false,
    width : 608,
//    height: 565,
    open: function () { 
    	if($("#resPopDialog").attr("schedule_type") == "U" || $("#resPopDialog").attr("favorite_type") == "Y") {
    		var obj = {};
    		obj = JSON.parse($("#resPopDialog").attr("partyList"));
    		$.each(obj, function (index, item) {
    			
//    			$("#select_dept_list").append('<li data-type=member data-memberid="'+item.MEMBER_ID+'" data-email="'+item.EMAIL+'" >'+ item.MEMBER_NM + '</li>');
    			if(item.MEMBER_ID == "")
         			$("#select_dept_list").append('<li data-type=email data-email="'+item.EMAIL+'" >'+ item.MEMBER_NM + '</li>');
         		else
         			$("#select_dept_list").append('<li data-type=member data-memberid="'+item.MEMBER_ID+'" data-email="'+item.EMAIL+'" >'+ item.MEMBER_NM + '</li>');
        		var select_participant = {};
            	$("#select_dept_list li").bind( "click", function() {
            	   	$(this).parent().find('li.selected').removeClass('selected');
            	   	$(this).parent().find('li.active').removeClass('active');
            	   	$(this).addClass('selected');
            	   	$(this).addClass('active');
                });
    		});
    	}
   	},
   	close: function () {
   		$("#step1").show();
   		$("#step2").hide();
   		$("#step3").hide();
   		$("#step4").hide();
   		$("#dept_list").children().remove();
   	    $("#select_dept_list").children().remove();
   	    $("#duration").val(10);
	    $("#conf_title").val('');
	    $("#start_date").val('');
	    $("#hourbox").val('00');
	    $("#minbox").val('00');
	    $("#conf_contents").val('');
	    $("#conf_pass").val('');
   	}
});
    	 
$('#resDetailPopupDialog').dialog({
    autoOpen: false,
    autoResize : true,
    resizable : false,
    closeOnEscape: true,
    modal: true,
    show: {
        effect: "show",
        duration: 1000
    },
    hide: {
        effect: "fadeOut",
        duration: 1000
    },
    hideCloseButton: false,
    width : 640,
    height: 500,
    open: function () {
    	
		var obj = {};
		obj = JSON.parse($("#resDetailPopupDialog").attr("detailpartyList"));
		$.each(obj, function (index, item) {
//			$("#detail_select_dept_list").append('<li data-type=member data-memberid="'+item.MEMBER_ID+'" data-email="'+item.EMAIL+'" >'+ item.MEMBER_NM + '</li>');
			if(item.MEMBER_ID == "")
         		$("#detail_select_dept_list").append('<li data-type=email data-email="'+item.EMAIL+'" >'+ item.MEMBER_NM + '</li>');
     		else
         		$("#detail_select_dept_list").append('<li data-type=member data-memberid="'+item.MEMBER_ID+'" data-email="'+item.EMAIL+'" >'+ item.MEMBER_NM + '</li>');
	    	var select_participant = {};
	        $("#detail_select_dept_list li").bind( "click", function() {
		        $(this).parent().find('li.selected').removeClass('selected');
		        $(this).parent().find('li.active').removeClass('active');
		        $(this).addClass('selected');
		        $(this).addClass('active');
	        });
		});
		
		var obj2 = {};
		obj2 = JSON.parse($("#resDetailPopupDialog").attr("detailendpointList"));
		$.each(obj2, function (index, item) {
			if(item.RES_KEY != "resource"){
				$('#detail_select_endpoint_list').append('<li>'+ item.ENDPOINT_NM +'</li>');
			}
        });
   	},
   	close: function () { 
   	    $("#detail_select_dept_list").children().remove();
   	    $("#detail_select_endpoint_list").children().remove();
	    $("#detail_conf_title_confirm").val('');
	    $("#detail_conf_date_confirm").val('');
	    $("#detail_conf_meetingKey_confirm").val('');
	    $("#detail_conf_host_confirm").val('');
	    $("#detail_conf_pass_confirm").val('');
	    $("#detail_conf_contents_confirm").val('');
   	}
});
