// ©


$(document).ready(function(){ // 기능
	$(".cont .date").datepicker({
		changeYear:true,
		changeMonth:true,
		dateFormat:"yy-mm-dd"
	});
	$.datepicker.setDefaults({
		prevText : "이전 달",
		nextText : "다음 달",
		dayNames: ["일요일", "월요일", "화요일", "수요일", "목요일", "금요일", "토요일", "일요일"],
		dayNamesShort: ["일", "월", "화", "수", "목", "금", "토", "일"],
		dayNamesMin: ["일", "월", "화", "수", "목", "금", "토", "일"],
		monthNames: ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"],
		monthNamesShort: ["1월", "2월", "3월", "4월", "5월", "6월", "7월", "8월", "9월", "10월", "11월", "12월"],
		yearSuffix:"년"
	});
});

$(document).ready(function(){ // 모바일용 메뉴
	function hambuger_navi_Hide(){
		$('.lnb').hide();
		$('.hambuger_navi').css('background-position','0 50%');
		bool = false;
	};

	function hambuger_navi_Show(){
		$('.lnb').show();
		$('.hambuger_navi').css('background-position','100% 50%');
		bool = true;
	};

	if($(document).width() < 751){
		hambuger_navi_Hide();
	}else{
		hambuger_navi_Show();
	};
	$('.hambuger_navi').click(function(){
		if(bool){
			hambuger_navi_Hide();
		}else{
			hambuger_navi_Show();
		}
	});

	$(window).resize(function() {
		if($(document).width() < 751){
			hambuger_navi_Hide();
		}else{
			hambuger_navi_Show();
		};
	});
});

$(document).ready(function(){ // 상단메뉴
	var lnb = $('.lnb');
	function onSelectNav(){
		var t = $(this);
		var myclass = [];
		t.parentsUntil('.lnb:first').filter('li').each(function(){
			myclass.push( $(this).attr('class') );
		});
		myclass = myclass.join(' ');
		if (!lnb.hasClass(myclass)) lnb.attr('class','lnb').addClass(myclass);
		$('.lnb li.on ul').css('display','none');
	}
	function onHideNav(){
		var t = $(this);
		var myclass = [];
		t.parentsUntil('.lnb:first').filter('li').each(function(){
			myclass.push( $(this).attr('class') );
		});
		if (!lnb.hasClass(myclass)) lnb.attr('class','lnb').removeClass(myclass);
		$('.lnb li.on ul').css('display','block');
	}
	lnb.find('li>a.bgbt').mouseover(onSelectNav);
	lnb.find('ul').mouseleave(onHideNav).blur(onHideNav);
});

$(document).ready(function(){ // 테이블 스크롤
	var h_wrap= $(window).innerHeight();
	$('#wrap').css('min-height',h_wrap+'px');

	var $table = $('.table_face.scroll'),$bodyCells = $table.find('tbody tr:first').children(),colWidth;

	colWidth = $bodyCells.map(function() {
		return $(this).width();
	}).get();

	$table.find('thead tr').children().each(function(i, v) {
		$(v).width(colWidth[i]+1);
	});

	$(window).resize(function() {
		var h_wrap= $(window).innerHeight();
		$('#wrap').css('min-height',h_wrap+'px');

		var $table = $('.table_face.scroll'),$bodyCells = $table.find('tbody tr:first').children(),colWidth;

		colWidth = $bodyCells.map(function() {
			return $(this).width();
		}).get();

		$table.find('thead tr').children().each(function(i, v) {
			$(v).width(colWidth[i]+1);
		}); 
	});
});

$(document).ready(function(){ // Contents Decoration
	$('.required').append('<span> (required)</span>');
	$('.rb').after('<div class=\'blank\'></div>');

	if ($('.cont.left.w_75p').innerHeight() < $('.cont.right.w_25p').innerHeight()){
		$('.cont.right.w_25p .list_info li:last-child').css('border-bottom',0);
	}
	var h_cont_left= $('.cont.left.w_75p').innerHeight()-49;
	$('.cont.right.w_25p .list_info').css('min-height',h_cont_left+'px');

	$(".table_face.scroll tbody").mCustomScrollbar({ // 테이블 스크롤 디자인
		scrollInertia:0
	});
});


	$(document).ready(function(){
		setInterval(time,1);
	});

	function getDay(arg_day){   //요일구하는 함수
		var day=["일","월","화","수","목","금","토"];
		return day[arg_day];
	}
	function time(){
		var date = new Date();
		var year = date.getFullYear();
		var month = ('0' + (date.getMonth() + 1)).slice(-2);
		var dateDate = ('0' + date.getDate()).slice(-2);
		var day = getDay(date.getDay());
		var hours = ('0' + date.getHours()).slice(-2);
		var minutes = ('0' + date.getMinutes()).slice(-2);
		var seconds = ('0' + date.getSeconds()).slice(-2);

		$(".time").html(hours+":"+minutes+":"+seconds)
		$(".date").html(year+"."+month+"."+dateDate+"("+day+")")
	}
