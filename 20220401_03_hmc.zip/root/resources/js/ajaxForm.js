function ajax(server_url,paramInfo) {
    return $.ajax({
    	async: true,
    	type: "POST", 
    	url: server_url, 
    	data : paramInfo,
    	dataType: "json", 
    	headers: {"AJAX": "true"}, 
    	success: function (result) {
    		return result;
		},
		beforeSend:function(){
			$('.Progress_Loading').show();
		},
		complete:function(){
			$('.Progress_Loading').hide();
		}, 
		error: function (xhr, ajaxOptions, thrownError) {
			if(xhr.status == 400){
				alert("세션이 만료되었습니다. 다시 로그인하시기 바랍니다.");
				location.href="${ctx}/index.do";
			}else{
				alert(thrownError);
			}
		}
	});
}

//동기식 처리방식
function ajaxAsyncF(server_url,paramInfo) {
    return $.ajax({
    	async: false,
    	type: "POST", 
    	url: server_url, 
    	data : paramInfo,
    	dataType: "json", 
    	headers: {"AJAX": "true"}, 
    	success: function (result) {
    		return result;
		},
		beforeSend:function(){
			$('.Progress_Loading').show();
		},
		complete:function(){
			$('.Progress_Loading').hide();
		}, 
		error: function (xhr, ajaxOptions, thrownError) {
			if(xhr.status == 400){
				alert("세션이 만료되었습니다. 다시 로그인하시기 바랍니다.");
				location.href="${ctx}/index.do";
			}else{
				alert(thrownError);
			}
		}
	});
}
