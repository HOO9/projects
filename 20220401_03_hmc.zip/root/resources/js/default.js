var _contextRoot = "'${ctx}'";

    document.write("<!--[if lt IE 9]><script src='" + _contextRoot + "/resources/js/html5.js'></script><![endif]-->");
	document.write("<script src='" + _contextRoot + "/resources/js/jquery-ui.js'></script>");
	document.write("<script src='" + _contextRoot + "/resources/js/jquery.mCustomScrollbar.concat.min.js'></script>");
	document.write("<script src='" + _contextRoot + "/resources/js/jquery-Layout.js'></script>");
	document.write("<script src='" + _contextRoot + "/resources/js/schedule.js'></script>");
    //document.write("<script src='" + _contextRoot + "/resources/js/jquery.shuttle.js'></script>");


$(document).ready(function(){
    function funLoad(){
        var Cheight = $('#content').height();
        var c_header = $('.content_header').height()+10;
        var btn_area = $('.btn_area').height()+10;
        var paging = $('.paging').height()+10;
        var title = $('.searchBox .title').height()+10;
        var title2 = $('.searchBox02 .title').height()+10;
        var bd_search = $('.bd_search').height()+10;
        var w_bd_search = $('.bd_search').width();
        var btn_search = $('.btn_search').width()+10;
        $('.searchBox').css({'height':Cheight+ - 40+ 'px'});
        $('.searchBox.h').css({'height':Cheight+ - 80+ 'px'});
        $('.searchBox02').css({'height':Cheight+ - 10+ 'px'});
        $('.list ul').css({'height':Cheight - c_header- title - bd_search - paging+ 'px'});
        $('.searchBox02 .list ul').css({'height':Cheight - title2 -120  + 'px'});
        $('.pannel.h_full').css({'height':Cheight+ - c_header + 'px'});
        $('.tab_container').css({'height':Cheight+ - 41+ 'px'});
        //$('.h_scroll').css({'height':Cheight+ -c_header - btn_area +10+ 'px'});
        //$('.bd_search input[type=text]').css({'width':w_bd_search -btn_search + 'px'});
    }
    window.onload = funLoad;
    window.onresize = funLoad;
    
    var uploadFile = $('.fileBox .uploadBtn');
    uploadFile.on('change', function(){
        if(window.FileReader){
            var filename = $(this)[0].files[0].name;
        } else {
            var filename = $(this).val().split('/').pop().split('\\').pop();
        }
        $(this).siblings('.fileName').val(filename);
    });
    
    // tab menu
    $(".tab_content").hide();
    $(".tab_content:first").show();

    $("ul.tabs li").click(function () {
        $("ul.tabs li").removeClass("active").css("color", "#333");
        //$(this).addClass("active").css({"color": "darkred","font-weight": "bolder"});
        $(this).addClass("active").css("color", "darkred");
        $(".tab_content").hide()
        var activeTab = $(this).attr("rel");
        $("#" + activeTab).fadeIn()
    });
    
    // button icon
    $(".report").hide();
    $(".report:first").show();

    $(".btn03").click(function () {
        $("#table").css("display", "block");
        //$(this).addClass("active").css({"color": "darkred","font-weight": "bolder"});
        $(this).addClass("active").css("color", "darkred");
        $(".report").hide()
        var activeTab2 = $(this).attr("rel");
        $("#" + activeTab2).fadeIn()
    });
    
    // combobox
    var combobox = $('.combobox');
    combobox.find('li').click(function(){
        $(this).removeClass('active');
        $(this).addClass('active');
    });
    
    // logout
    $(".popup").hide();
    $(".logout").click(function () {
        $(".popup").show();
        $("#wrap").css("filter", "blur(2px)");
    });
});